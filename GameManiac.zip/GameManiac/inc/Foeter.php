<?php function Footer2()
{
 ?>
<footer>
	<div>
		<a href="about.php">About</a>
		|
		<a href="contact.php">Contact</a>
	</div>
</footer>
<?php
}
?>
