<?php 
function Headertest()
{
 ?>
 <header id="header">
            <a href="index.php">
            <div id="logo">
                <img src="img/logo.png" style="width:174px;height:70px;">
                Heroes
            </div>
            </a>
</header>
<?php
}
?>
